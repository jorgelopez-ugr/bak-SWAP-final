#!/bin/bash

# Script: entrypoint.sh
./jorgelpz-iptables-web.sh
exec "$@"