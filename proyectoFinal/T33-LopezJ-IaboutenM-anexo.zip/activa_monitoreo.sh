#!/bin/bash

# Navegar a la carpeta monitoreo
cd ./monitoreo
# Ejecutar docker-compose
docker-compose up -d