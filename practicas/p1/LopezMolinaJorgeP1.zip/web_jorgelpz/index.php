<Doctype html>
<html>
    <head>
        <title>SWAP - P1</title>
    </head>
    <body>
        <h1>Práctica SWAP - Jorge López Molina</h1>
        <p>Dirección IP del servidor Apache: <?php echo $_SERVER['SERVER_ADDR']; ?></p>
        <p>Software del servidor: <?php echo $_SERVER['SERVER_SOFTWARE']; ?></p>
    </body>
</html>
