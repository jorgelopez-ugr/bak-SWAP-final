#!/bin/bash

cd ./parser

echo "Parseando..."
docker-compose up -d